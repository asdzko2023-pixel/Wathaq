# WATHAQ Burgundy Identity — v0.7

## Approved direction
- Identity: Burgundy / warm ivory / champagne gold.
- Motion: minimal, calm logo entrance; no dramatic particle or orbit effects.
- Appearance: light and dark modes, with system preference as the default and user selection retained.
- Existing WATHAQ logo: preserved byte-for-byte. No redraw, recolor, crop, or replacement of the original brand artwork.

## Core palette
- Light canvas: `#FBF6F4`
- Light surface: `#FFFFFF`
- Light text: `#28151B`
- Burgundy primary: `#812A43`
- Burgundy deep: `#672036`
- Champagne gold: `#E7C17B`
- Dark canvas: `#160D12`
- Dark surface: `#24151D`
- Dark text: `#FFF7F5`
- Dark rose accent: `#D7A9B7`

## UX principles
- Keep customer flows simple and thumb-friendly.
- Preserve the existing Arabic RTL content and loyalty workflows.
- Use restrained transitions and respect `prefers-reduced-motion`.
- Never imply unfinished capabilities are available.
- Maintain contrast between text and surfaces in both modes.

## Scope of v0.7 UI pass
- Customer app: shared theme, cards, navigation, forms, login and OTP visual treatment, splash.
- Staff app: align shared color language and dark-mode colors.
- Merchant app: align merchant dashboard primary and surface colors; support system dark mode.
- No database schema, RLS, reward logic, or authentication provider changes.
