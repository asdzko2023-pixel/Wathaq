// Smoke test for the customer app logic with a stubbed DOM and a fake Supabase client. No network needed.
// Run: node app/test/smoke.mjs
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
const src = readFileSync(join(dirname(fileURLToPath(import.meta.url)), '../src/app.mjs'), 'utf8').replace(/^import .*$/m, '');
const results = []; const ok = (name, cond) => { results.push([name, !!cond]); };
const H = {}; let hash = ''; const app = { innerHTML: '' }; const list = { innerHTML: '' }; const calls = []; let ticker = null;
const fire = (t, ev) => (H[t] || []).forEach((f) => f(ev));
const location = { origin: 'https://x.github.io', pathname: '/wathaq/', get hash() { return hash; }, set hash(v) { hash = v; fire('hashchange', {}); } };
const sstore = {}; const sessionStorage = { getItem: (k) => (k in sstore ? sstore[k] : null), setItem: (k, v) => { sstore[k] = String(v); }, removeItem: (k) => { delete sstore[k]; } };
const store = {}; const localStorage = { getItem: (k) => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); }, removeItem: (k) => { delete store[k]; } };
Object.defineProperty(localStorage, 'length', { get: () => Object.keys(store).length });
const BAD = '<img src=x onerror=alert(1)>';
const DATA = {
  merchants: [{ id: 'm1', name: BAD, category: 'المقاهي', description: 'وصف', city: 'عدن', area: 'كريتر', is_test: true, programs: [{ id: 'p1', type: 'stamps', name: 'أختام', rules: { target: 8, earn_text: 'ختم لكل مشروب' } }] }],
  rewards: [{ id: 'r1', title: 'قهوة مجانية', cost: 8, program_id: 'p1', merchant_id: 'm1' }],
  cards: [], transactions: [], favorites: [], profiles: { display_name: 'أحمد' },
};
const chain = (table) => { const c = new Proxy(function () {}, { get: (_, k) => (k === 'then' ? (res) => res({ data: DATA[table] ?? [], error: null }) : (...a) => { if (['insert', 'update', 'delete'].includes(k)) calls.push([table, k, a[0]]); return c; }), apply: () => c }); return c; };
let authCb; let session = null;
const sbStub = { from: (t) => chain(t), rpc: (n, a) => { calls.push(['rpc', n, a]); if (n === 'my_tier') return Promise.resolve({ data: 'bronze', error: null }); if (n === 'join_program') { DATA.cards = [{ id: 'c1', stamps: 0, points: 0, created_at: new Date().toISOString(), program_id: 'p1', merchant_id: 'm1', programs: { id: 'p1', type: 'stamps', name: 'أختام', rules: { target: 8 } }, merchants: { id: 'm1', name: BAD, category: 'المقاهي' } }]; return Promise.resolve({ data: 'c1', error: null }); } return Promise.resolve({ data: null, error: null }); },
  auth: { getSession: async () => ({ data: { session } }), onAuthStateChange: (cb) => { authCb = cb; }, signInWithOtp: async (a) => { calls.push(['otp', a]); return { error: null }; },
    signUp: async (a) => { calls.push(['signup', a]); if (a.email === 'down@x.com') return { data: {}, error: { message: 'Error sending confirmation email', status: 500, code: 'unexpected_failure' } }; if (a.email === 'auto@x.com') { const u = { id: 'u9', email: a.email, email_confirmed_at: 'x' }; authCb('SIGNED_IN', { user: u }); return { data: { user: u, session: { user: u } }, error: null }; } return { data: { user: { id: 'u2', email: a.email, email_confirmed_at: null }, session: null }, error: null }; },
    resend: async (a) => { calls.push(['resend', a]); return { error: null }; },
    signInWithPassword: async (a) => { calls.push(['pwlogin', a]); if (a.email === 'new@x.com') return { error: { message: 'Email not confirmed', code: 'email_not_confirmed', status: 400 } }; if (a.password !== 'Correct-Pass-1') return { error: { message: 'Invalid login credentials', code: 'invalid_credentials', status: 400 } }; session = { user: { id: 'u2', email: a.email, email_confirmed_at: 'x' } }; authCb('SIGNED_IN', session); return { error: null }; },
    verifyOtp: async (a) => { calls.push(['verify', a]); if (a.email) { if (a.token !== '123456') return { error: { message: 'Token has expired or is invalid', code: 'otp_expired', status: 403 } }; session = { user: { id: 'u2', email: a.email, email_confirmed_at: 'x' } }; authCb('SIGNED_IN', session); return { error: null }; } session = { user: { id: 'u1', phone: '967777000001', phone_confirmed_at: 'x' } }; authCb('SIGNED_IN', session); return { error: null }; }, signOut: async () => { session = null; authCb('SIGNED_OUT', null); } } };
const ctx = {
  createClient: () => sbStub, window: { WATHAQ_CONFIG: { url: 'https://x.supabase.co', key: 'k' }, addEventListener: (t, f) => { (H[t] = H[t] || []).push(f); }, scrollTo() {} },
  document: { querySelector: (s) => (s === '#app' ? app : s === '#list' ? list : null), addEventListener: (t, f) => { (H[t] = H[t] || []).push(f); }, documentElement: { setAttribute() {} }, createElement: () => ({ setAttribute() {}, remove() {}, style: {} }), body: { appendChild() {} } },
  localStorage, sessionStorage, location, navigator: { onLine: true }, history: { length: 1, back() {} }, fetch: async () => ({ json: async () => ({ external: { phone: true, email: true, google: false }, mailer_autoconfirm: false }) }),
  confirm: () => true, setInterval: (f) => { ticker = f; return 1; }, clearInterval() {}, setTimeout: (f) => { try { f(); } catch {} return 0; }, Object, JSON, Date, Promise, RegExp, Array, String, Set, Math, console, Proxy,
};
const names = Object.keys(ctx);
const run = new Function(...names, src);
run(...names.map((n) => ctx[n]));
const wait = () => new Promise((r) => setImmediate(r)); const tick = async () => { for (let i = 0; i < 8; i++) await wait(); };
const click = (a) => fire('click', { target: { closest: () => ({ dataset: { a }, disabled: false }) } });
const input = (id, value) => fire('input', { target: { id, value } });
await tick();
ok('logged-out user lands on login', hash === '#/login' && app.innerHTML.includes('إرسال الرمز برسالة نصية'));
ok('no WhatsApp option is offered', !/واتساب|whatsapp/i.test(app.innerHTML));
input('phone', '123'); click('sendotp'); await tick();
ok('invalid phone shows an error and sends nothing', app.innerHTML.includes('أدخل رقم هاتف صحيحًا') && !calls.some((c) => c[0] === 'otp'));
input('phone', '٠٧٧٧٠٠٠٠٠١'.replace('٠٧', '٧') + '٠'); // Arabic-Indic digits are normalised
input('phone', '777 000 001'); click('sendotp'); await tick();
const sent = calls.find((c) => c[0] === 'otp');
ok('OTP requested by SMS for +967 number', sent && sent[1].phone === '+967777000001' && !('channel' in sent[1]));
ok('OTP screen shown', hash === '#/otp' && app.innerHTML.includes('أدخل رمز التحقق'));
input('tok', '12'); click('verify'); await tick();
ok('short code rejected locally', app.innerHTML.includes('6 أرقام'));
input('tok', '123456'); click('verify'); await tick();
const v = calls.find((c) => c[0] === 'verify');
ok('verifyOtp called with type sms', v && v[1].type === 'sms' && v[1].token === '123456' && v[1].phone === '+967777000001');
ok('signed-in user reaches home with real data states', hash === '#/home' && app.innerHTML.includes('بطاقات نشطة') && app.innerHTML.includes('لم تنضم إلى أي برنامج'));
hash = '#/discover'; fire('hashchange', {}); await tick();
ok('discover escapes untrusted store names (no raw HTML injection)', !app.innerHTML.includes('<img src=x') && app.innerHTML.includes('&lt;img'));
ok('test merchants are labelled', app.innerHTML.includes('بيانات تجريبية'));
input('q', 'لا يوجد'); ok('search with no match shows empty state', list.innerHTML.includes('لا توجد متاجر مطابقة')); input('q', '');
hash = '#/store/m1'; fire('hashchange', {}); await tick();
ok('store page shows terms before joining', app.innerHTML.includes('ختم لكل مشروب') && app.innerHTML.includes('انضم إلى برنامج الولاء'));
click('join:p1'); await tick();
ok('join uses the server RPC, not a direct card insert', calls.some((c) => c[0] === 'rpc' && c[1] === 'join_program' && c[2].p_program_id === 'p1') && !calls.some((c) => c[0] === 'cards'));
ok('after joining, card page opens and shows derived text', hash === '#/card/c1' && app.innerHTML.includes('بقي لك 8 أختام للوصول إلى مكافأتك.'));
ok('redeem is honestly disabled (server function not built)', /disabled>تحتاج 8 أختام إضافية|disabled>الاستبدال سيتوفر قريبًا/.test(app.innerHTML));
ok('client never writes balances', !calls.some((c) => ['cards', 'transactions', 'reward_tokens'].includes(c[0]) && ['insert', 'update', 'delete'].includes(c[1])));
fire('offline', {}); ok('offline banner appears', app.innerHTML.includes('أنت غير متصل')); fire('online', {});
hash = '#/account'; fire('hashchange', {}); await tick();
ok('account shows verified phone and tier', app.innerHTML.includes('الهاتف موثّق') && app.innerHTML.includes('برونزي'));
click('logout'); await tick();
ok('logout returns to login', hash === '#/login');
ok('no "undefined" leaked into the UI', !app.innerHTML.includes('undefined') && !app.innerHTML.includes('NaN'));

// ---------- email: password sign-up confirmed by a 6-digit code ----------
const callsOf = (k) => calls.filter((c) => c[0] === k);
const noLeak = () => !JSON.stringify([store, sstore]).includes('Correct-Pass-1');
hash = '#/login'; fire('hashchange', {}); await tick();
ok('email option is offered (no magic-link button text)', app.innerHTML.includes('المتابعة بالبريد الإلكتروني') && !app.innerHTML.includes('إرسال رابط الدخول'));
click('emailopen'); await tick();
ok('email screen opens', hash === '#/email' && app.innerHTML.includes('البريد الإلكتروني') && app.innerHTML.includes('كلمة المرور'));
click('emode:up'); input('email', 'bad'); input('pw', 'Correct-Pass-1'); click('emailsubmit'); await tick();
ok('invalid email is rejected locally and nothing is sent', app.innerHTML.includes('أدخل بريدًا إلكترونيًا صحيحًا') && !callsOf('signup').length);
input('email', 'Ali@Example.com'); input('pw', 'short'); click('emailsubmit'); await tick();
ok('short password is rejected locally', app.innerHTML.includes('8 أحرف') && !callsOf('signup').length);
input('pw', 'Correct-Pass-1'); click('emailsubmit'); await tick();
const su = callsOf('signup')[0];
ok('signUp called with normalised email + password and NO redirect link option', su && su[1].email === 'ali@example.com' && su[1].password === 'Correct-Pass-1' && !('options' in su[1]));
ok('after sign-up the user lands on the code screen, not home', hash === '#/verify-email' && app.innerHTML.includes('تأكيد البريد الإلكتروني') && app.innerHTML.includes('ali@example.com'));
ok('email is NOT treated as confirmed: no session, no protected data, no nav bar', !app.innerHTML.includes('w-nav') && !app.innerHTML.includes('بطاقات نشطة'));
ok('no email sign-in link was ever requested', !calls.some((c) => c[0] === 'otp' && c[1].email));
ok('password is never persisted to local/session storage', noLeak());
ok('code input is numeric, one-time-code, max 6', /inputmode="numeric"[^>]*autocomplete="one-time-code"[^>]*maxlength="6"/.test(app.innerHTML));
ok('code screen has the confirm button, a resend button with timer, and a fix-email button', app.innerHTML.includes('>تأكيد البريد الإلكتروني</button>') && app.innerHTML.includes('إعادة الإرسال بعد 60 ث') && app.innerHTML.includes('تصحيح البريد الإلكتروني'));
// refresh simulation: pending email survives, password does not
ok('pending email stored for refresh, password not stored', JSON.parse(sstore['w-pend']) === 'ali@example.com' && !('w-pw' in sstore));
click('eresend'); await tick();
ok('resend is blocked while the cooldown is running', !callsOf('resend').length);
const pasted = { id: 'etok', value: ' ٩٨٧-٦٥٤abc321 ' }; fire('input', { target: pasted });
ok('pasted code is normalised to digits and capped at 6', pasted.value === '987654');
input('etok', '12'); click('everify'); await tick();
ok('short code rejected locally, verifyOtp not called', app.innerHTML.includes('6 أرقام') && !callsOf('verify').some((c) => c[1].email));
input('etok', '000000'); click('everify'); await tick();
ok('wrong / expired code is rejected with a clear message and no session', callsOf('verify').some((c) => c[1].email && c[1].token === '000000') && app.innerHTML.includes('غير صحيح أو انتهت صلاحيته') && hash === '#/verify-email' && !session);
for (let i = 0; i < 4; i++) { input('etok', '111111'); click('everify'); await tick(); }
const before = callsOf('verify').length; input('etok', '123456'); click('everify'); await tick();
ok('after 5 failures the client pauses attempts (server limits still apply)', callsOf('verify').length === before && app.innerHTML.includes('محاولات كثيرة') && hash === '#/verify-email');
{ const RealNow = Date.now; Date.now = () => RealNow() + 61000; input('etok', '123456'); click('everify'); await tick(); Date.now = RealNow; }
const ve = callsOf('verify').filter((c) => c[1].email).pop();
ok('verifyOtp uses email + 6-digit token + type email', ve && ve[1].email === 'ali@example.com' && ve[1].token === '123456' && ve[1].type === 'email');
ok('correct code confirms email and opens home', hash === '#/home' && session && session.user.email_confirmed_at && app.innerHTML.includes('بطاقات نشطة'));
ok('pending-verification state cleared after success', !('w-pend' in sstore));
hash = '#/account'; fire('hashchange', {}); await tick();
ok('account shows email verified', app.innerHTML.includes('البريد موثّق'));
click('logout'); await tick();
ok('logout works for email user and clears state', hash === '#/login' && !session);
// sign-in paths
click('emailopen'); await tick(); click('emode:in'); input('email', 'ali@example.com'); input('pw', 'wrong-pass'); click('emailsubmit'); await tick();
ok('wrong password gives a generic message (no account enumeration)', app.innerHTML.includes('البريد الإلكتروني أو كلمة المرور غير صحيحة') && hash === '#/email');
input('pw', 'Correct-Pass-1'); click('emailsubmit'); await tick();
ok('confirmed user signs in with password', hash === '#/home' && !!session);
click('logout'); await tick();
click('emailopen'); await tick(); click('emode:in'); input('email', 'new@x.com'); input('pw', 'Correct-Pass-1'); const rs0 = callsOf('resend').length; click('emailsubmit'); await tick();
ok('unconfirmed user signing in is sent to the code screen and a code is re-sent', hash === '#/verify-email' && callsOf('resend').length === rs0 + 1 && callsOf('resend').pop()[1].type === 'signup' && !session);
// resend after the cooldown ends, then blocked again (abuse limit)
for (let i = 0; i < 60; i++) ticker && ticker();
const rs1 = callsOf('resend').length; click('eresend'); await tick();
ok('resend works once the timer ends and uses type signup for the pending email', callsOf('resend').length === rs1 + 1 && callsOf('resend').pop()[1].email === 'new@x.com' && app.innerHTML.includes('أرسلنا رمزًا جديدًا'));
click('eresend'); await tick();
ok('a second immediate resend is blocked (cooldown restarted)', callsOf('resend').length === rs1 + 1 && app.innerHTML.includes('إعادة الإرسال بعد 60 ث'));
// protected-screen gate: an unconfirmed session must never be accepted
click('echange'); await tick();
ok('"fix email" returns to sign-up and clears pending state', hash === '#/email' && !('w-pend' in sstore));
authCb('SIGNED_IN', { user: { id: 'u3', email: 'ghost@x.com', email_confirmed_at: null } }); await tick();
ok('a session whose email is NOT confirmed is rejected (no home, no nav)', hash !== '#/home' && !app.innerHTML.includes('w-nav'));
hash = '#/home'; fire('hashchange', {}); await tick();
ok('protected route without a verified user redirects to login', hash === '#/login');
// provider failures
click('emailopen'); await tick(); click('emode:up'); input('email', 'down@x.com'); input('pw', 'Correct-Pass-1'); click('emailsubmit'); await tick();
ok('mail-provider error is shown clearly and user stays on sign-up', app.innerHTML.includes('تعذّر إرسال رسالة التحقق') && hash === '#/email');
input('email', 'auto@x.com'); click('emailsubmit'); await tick();
ok('if the server auto-confirms (OTP not enforced) the session is dropped, never trusted', !session && hash !== '#/home');

let fail = 0; for (const [n, p] of results) { console.log((p ? 'PASS  ' : 'FAIL  ') + n); if (!p) fail++; }
console.log(fail ? `\n${fail} FAILED` : `\nAll ${results.length} smoke tests passed`); process.exit(fail ? 1 : 0);
