// WATHAQ service worker. Network-first for navigations and application code;
// Supabase Auth/API requests are never intercepted or cached.
const V = 'wathaq-v0.5.0';
const SHELL = ['./', './index.html', './config.js', './manifest.webmanifest', './assets/mark.png', './assets/logo.png', './icons/icon-192.png'];
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(V).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key.startsWith('wathaq-') && key !== V).map((key) => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const r = e.request;
  if (r.method !== 'GET') return;
  const u = new URL(r.url), same = u.origin === self.location.origin;
  const authOrApi = /\/auth\/v1\/|\/rest\/v1\/|\/functions\/v1\//.test(u.pathname);
  if (!same || authOrApi) return;
  const isNavigation = r.mode === 'navigate' || (r.destination === 'document');
  const isCode = /\.(?:m?js|css)$/.test(u.pathname);
  if (isNavigation || isCode) {
    e.respondWith(fetch(r).then((res) => {
      if (res.ok) { const copy = res.clone(); caches.open(V).then((cache) => cache.put(r, copy)); }
      return res;
    }).catch(async () => (await caches.match(r)) || (isNavigation ? await caches.match('./index.html') : Response.error())));
    return;
  }
  e.respondWith(caches.match(r).then((hit) => hit || fetch(r).then((res) => {
    if (res.ok) { const copy = res.clone(); caches.open(V).then((cache) => cache.put(r, copy)); }
    return res;
  })));
});
