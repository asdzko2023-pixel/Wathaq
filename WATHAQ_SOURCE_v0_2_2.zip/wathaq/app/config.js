// Supabase connection for the DEV project. The publishable key is designed to be public (RLS protects the data).
// Never put a secret key here.
window.WATHAQ_CONFIG = {
  url: 'https://rnohdqevwkoggplldmiv.supabase.co',
  key: 'sb_publishable_0NL5kOvG_Hq5Hk2s4rYnIw_gXWv2qFU',
  env: 'dev'
};
