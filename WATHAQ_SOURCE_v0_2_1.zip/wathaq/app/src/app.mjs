// WATHAQ customer app v0.1 (test build). Vanilla ES module. Server is the source of truth: this app never writes balances.
import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/+esm';
const CFG = window.WATHAQ_CONFIG || {};
const $ = (s) => document.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const ls = { get(k) { try { return JSON.parse(localStorage.getItem(k)); } catch { return null; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} }, del(k) { try { localStorage.removeItem(k); } catch {} } };
const ss = { get(k) { try { return JSON.parse(sessionStorage.getItem(k)); } catch { return null; } }, set(k, v) { try { sessionStorage.setItem(k, JSON.stringify(v)); } catch {} }, del(k) { try { sessionStorage.removeItem(k); } catch {} } };
// Normalises Arabic-Indic / Persian digits and strips everything else (Yemeni keyboards often type ٠-٩).
const digits = (v) => String(v || '').replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[۰-۹]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/\D/g, '');
const sb = CFG.url && CFG.key ? createClient(CFG.url, CFG.key, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } }) : null;
const S = { user: null, authCfg: { phone: true, email: false, google: false }, online: navigator.onLine, stale: false, step: 'phone', chan: 'phone', phone: '', tok: '', email: '', name: '', busy: false, err: '', info: '', cd: 0, until: 0, tries: 0, last: '', rk: '', q: '', cat: 'الكل', cf: 'all', emailOpen: false, d: {}, e: {}, tier: null, theme: ls.get('w-theme') || '' };
const CATS = ['الكل', 'المطاعم', 'المقاهي', 'الحلويات والمخابز', 'البقالات والسوبرماركت', 'الملابس', 'العطور ومستحضرات التجميل', 'الصالونات', 'الإلكترونيات', 'أخرى'];
const I = { home: '<path d="M4 11l8-7 8 7v8a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1z"/>', compass: '<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>', cards: '<rect x="3" y="6" width="18" height="13" rx="3"/><path d="M3 10h18"/>', act: '<path d="M4 6h16M4 12h16M4 18h10"/>', user: '<circle cx="12" cy="8" r="4"/><path d="M4 20c1-4 4-6 8-6s7 2 8 6"/>', check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>', clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', x: '<circle cx="12" cy="12" r="9"/><path d="M9 9l6 6M15 9l-6 6"/>', back: '<path d="M9 6l6 6-6 6"/>', info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>', bell: '<path d="M6 17V11a6 6 0 0 1 12 0v6l2 2H4zM10 21h4"/>', heart: '<path d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2 4 4 0 0 1 7 2c0 5.5-7 10-7 10z"/>', pin: '<path d="M12 21s-6-5-6-10a6 6 0 0 1 12 0c0 5-6 10-6 10z"/><circle cx="12" cy="11" r="2"/>', off: '<path d="M3 3l18 18M8.5 16.5a5 5 0 0 1 7 0M5 12.5a10 10 0 0 1 4-2.5"/>', gift: '<rect x="4" y="10" width="16" height="10" rx="2"/><path d="M12 10v10M4 14h16"/>' };
const ic = (n, s = '') => `<svg class="w-ico" viewBox="0 0 24 24" aria-hidden="true" style="${s}">${I[n]}</svg>`;
const dia = '<svg viewBox="0 0 24 32" aria-hidden="true"><path d="M12 2l9 14-9 14-9-14z"/></svg>';
const stamps = (n, h) => `<ol class="w-stamps w-num" style="--cols:${n}" aria-label="${h} من ${n} أختام">${Array.from({ length: n }, (_, i) => `<li class="${i < h ? 'on' : 'off'}" style="--n:${i}">${dia}<span>${i + 1}</span></li>`).join('')}</ol>`;
const bd = (k, i, t) => `<span class="w-badge w-badge--${k}">${ic(i)}${t}</span>`;
const pr = (p) => `<div class="w-progress" role="progressbar" aria-valuenow="${p}" aria-valuemin="0" aria-valuemax="100"><i style="--p:${p}%"></i></div>`;
const plu = (n, one, two, few, many) => (n === 1 ? one : n === 2 ? two : n >= 3 && n <= 10 ? `${n} ${few}` : `${n} ${many}`);
const stT = (n) => plu(n, 'ختم واحد', 'ختمان', 'أختام', 'ختمًا');
const ptT = (n) => plu(n, 'نقطة واحدة', 'نقطتان', 'نقاط', 'نقطة');
const PAL = ['#1F5C4D', '#8A5A10', '#7A2E3B', '#2A303A', '#315EA8', '#5B3A8A'];
const col = (id) => PAL[[...String(id)].reduce((a, c) => a + c.charCodeAt(0), 0) % PAL.length];
const logo = (m, s = 44) => `<span class="w-logo" style="--m:${col(m.id)};width:${s}px;height:${s}px">${esc((m.name || '؟')[0])}</span>`;
const fmtD = (iso) => { const d = new Date(iso), t = new Date(), y = new Date(Date.now() - 864e5), same = (a, b) => a.toDateString() === b.toDateString(); return same(d, t) ? 'اليوم' : same(d, y) ? 'أمس' : d.toLocaleDateString('ar-u-nu-latn', { day: 'numeric', month: 'long' }); };
const fmtT = (iso) => new Date(iso).toLocaleTimeString('ar-u-nu-latn', { hour: 'numeric', minute: '2-digit' });
// ---------- business display logic (reads only) ----------
function calc(c, rw) {
  const p = c.programs || {}, R = rw.filter((x) => x.program_id === p.id).sort((a, b) => a.cost - b.cost);
  if (p.type === 'stamps') { const goal = +(p.rules && p.rules.target) || (R[0] && R[0].cost) || 0, have = c.stamps, left = Math.max(goal - have, 0); return { type: 's', goal, have, left, ready: goal > 0 && left === 0, pct: goal ? Math.min(100, Math.round((have / goal) * 100)) : 0, R }; }
  const have = c.points, next = R.find((x) => x.cost > have), aff = R.filter((x) => x.cost <= have), goal = next ? next.cost : (R.length ? R[R.length - 1].cost : 0);
  return { type: 'p', goal, have, left: next ? next.cost - have : 0, ready: aff.length > 0, pct: goal ? Math.min(100, Math.round((have / goal) * 100)) : 0, R, next };
}
const need = (x) => (x.type === 's' ? `بقي لك ${stT(x.left)} للوصول إلى مكافأتك.` : x.next ? `بقي لك ${ptT(x.left)} للمكافأة التالية.` : 'وصلت إلى أعلى مكافأة متاحة في هذا البرنامج.');
// ---------- data ----------
const q = async (p) => { const { data, error } = await p; if (error) throw error; return data; };
async function load(key, fn) { const ck = 'wc:' + S.user.id + ':' + key; try { const v = await fn(); ls.set(ck, v); S.d[key] = v; delete S.e[key]; } catch (e) { const c = ls.get(ck); if (c) { S.d[key] = c; S.stale = true; } else S.e[key] = 1; } }
async function loadAll() {
  S.stale = false; S.e = {};
  await Promise.all([
    load('cards', () => q(sb.from('cards').select('id,stamps,points,created_at,program_id,merchant_id,programs(id,type,name,rules),merchants(id,name,category,is_test)').order('created_at', { ascending: false }))),
    load('stores', () => q(sb.from('merchants').select('id,name,category,description,city,area,is_test,programs(id,type,name,rules)').eq('status', 'approved').order('name'))),
    load('rewards', () => q(sb.from('rewards').select('id,title,cost,program_id,merchant_id').eq('is_active', true).order('cost'))),
    load('tx', () => q(sb.from('transactions').select('id,type,amount,reason,created_at,card_id,cards(merchants(name),programs(type,name))').order('created_at', { ascending: false }).limit(60))),
    load('favs', () => q(sb.from('favorites').select('merchant_id'))),
    load('tier', async () => { const t = await q(sb.rpc('my_tier')); return { v: t }; }),
    load('profile', async () => { const p = await q(sb.from('profiles').select('display_name').eq('id', S.user.id).maybeSingle()); return p || {}; }),
  ]);
  if (S.d.profile) S.name = S.d.profile.display_name || '';
  render();
}
// ---------- UI pieces ----------
const lcard = (c, x, i = 0) => `<a class="w-lcard" href="#/card/${c.id}" style="--m:${col(c.merchants.id)};--i:${i};text-decoration:none"><div class="w-lcard__head">${logo(c.merchants)}<div style="flex:1"><b>${esc(c.merchants.name)}</b><div class="m">${x.type === 's' ? 'بطاقة أختام' : 'برنامج نقاط'}</div></div><span class="w-num" style="font-weight:700">${x.have} / ${x.goal || '—'}</span></div><div style="margin-top:12px">${x.type === 's' && x.goal && x.goal <= 12 ? stamps(x.goal, x.have) : pr(x.pct)}</div>${x.ready ? '<div style="margin-top:8px">' + bd('success', 'check', 'جاهزة للاستبدال') + '</div>' : ''}</a>`;
const row = (m, t, s, b = '', href = '') => `<${href ? 'a href="' + href + '"' : 'div'} class="ro" style="text-decoration:none;color:inherit">${logo(m, 40)}<div><b>${esc(t)}</b><div class="m">${esc(s)}</div></div>${b}</${href ? 'a' : 'div'}>`;
const skel = () => '<div class="px">' + [[104, 8], [132, 12], [96, 12], [96, 12]].map(([h, m]) => `<div class="w-skel" style="height:${h}px;margin:${m}px 0"></div>`).join('') + '</div>';
const errBox = () => `<div class="px"><div class="w-card w-state">${ic('x', 'width:40px;height:40px;color:var(--color-danger)')}<h3>تعذّر تحميل البيانات</h3><p>تحقق من الإنترنت ثم حاول مجددًا. بياناتك لم تتأثر.</p><button class="w-btn w-btn--secondary" data-a="retry">إعادة المحاولة</button></div></div>`;
const empty = (t, p, b) => `<div class="w-state"><div style="width:220px;margin:0 auto 16px">${stamps(6, 0)}</div><h3>${t}</h3><p>${p}</p>${b || ''}</div>`;
const top = (t, right = '<span style="width:48px"></span>') => `<div class="h"><button class="w-btn w-btn--secondary" aria-label="رجوع" data-a="back" style="width:48px;padding:0">${ic('back')}</button><b>${t}</b>${right}</div>`;
const sec = (t, more = '') => `<div class="h2">${t}${more}</div>`;
// ---------- screens ----------
function login() {
  const a = S.authCfg, none = !a.phone && !a.email && !a.google;
  return `<div class="px"><div style="padding-top:48px;text-align:center"><img alt="وِثاق" src="./assets/mark.png" style="height:72px"></div><h1 class="h1" style="margin-top:28px">مرحبًا بك في وِثاق</h1><p class="m" style="font-size:16px;margin:8px 0 28px">سجّل دخولك لتتابع بطاقات الولاء والمكافآت في مكان واحد.</p>
  ${a.phone ? `<label class="w-field"><span>رقم الهاتف</span><div style="display:flex;gap:8px"><span class="w-input w-num" style="width:84px;display:grid;place-items:center" dir="ltr">+967</span><input id="phone" class="w-input w-num" dir="ltr" inputmode="tel" autocomplete="tel-national" placeholder="7XX XXX XXX" value="${esc(S.phone)}" style="flex:1" ${S.err ? 'aria-invalid="true"' : ''}></div></label><button class="w-btn w-btn--primary w-btn--block" data-a="sendotp"${S.busy ? ' aria-busy="true"' : ''}>إرسال الرمز برسالة نصية</button>` : ''}
  ${S.err ? `<div class="w-error-text" role="alert">${ic('x', 'width:16px;height:16px')}${esc(S.err)}</div>` : ''}
  ${none ? '<div class="note">' + ic('info') + 'طرق تسجيل الدخول غير مفعّلة بعد في بيئة الاختبار.</div>' : ''}
  ${a.email || a.google ? '<div class="m" style="text-align:center;margin:20px 0">أو تابع بـ</div><div style="display:grid;gap:8px">' + (a.google ? '<button class="w-btn w-btn--secondary w-btn--block" data-a="google">المتابعة بحساب جوجل</button>' : '') + (a.email ? (S.emailOpen ? `<label class="w-field"><span>البريد الإلكتروني</span><input id="email" class="w-input" dir="ltr" type="email" autocomplete="email" value="${esc(S.email)}"></label><button class="w-btn w-btn--secondary w-btn--block" data-a="email">إرسال رمز إلى البريد</button>` : '<button class="w-btn w-btn--secondary w-btn--block" data-a="emailopen">البريد الإلكتروني</button>') : '') + '</div>' : ''}
  ${S.info ? `<div class="note" style="margin-top:16px" role="status">${ic('check')}${esc(S.info)}</div>` : ''}
  <p class="m" style="text-align:center;font-size:12px;margin-top:24px">بالمتابعة توافق على شروط الاستخدام وسياسة الخصوصية.</p></div>`;
}
function otp() {
  const em = S.chan === 'email', dest = em ? S.email : S.phone.replace(/(\+\d{3})(\d)(\d+)(\d{3})/, '$1 $2•• ••• $4');
  return `<div class="px">${top('', '<span></span>')}<h1 class="h1" style="margin-top:8px">أدخل رمز التحقق</h1><p class="m" style="font-size:16px;margin:8px 0 28px">أرسلنا رمزًا مكوّنًا من 6 أرقام ${em ? 'إلى بريدك' : 'برسالة نصية إلى'} <span class="w-num" dir="ltr" style="word-break:break-all">${esc(dest)}</span></p>
  <label class="w-field"><span>رمز التحقق</span><input id="tok" class="w-input w-num" dir="ltr" inputmode="numeric" enterkeyhint="done" autocomplete="one-time-code" maxlength="6" pattern="[0-9]*" value="${esc(S.tok)}" style="text-align:center;font-size:24px;letter-spacing:8px" ${S.err ? 'aria-invalid="true"' : ''}></label>
  ${S.err ? `<div class="w-error-text" role="alert">${ic('x', 'width:16px;height:16px')}${esc(S.err)}</div>` : ''}
  <button class="w-btn w-btn--primary w-btn--block" style="margin-top:16px" data-a="verify"${S.busy ? ' aria-busy="true"' : ''}>${em ? 'تأكيد البريد الإلكتروني' : 'تحقق'}</button>
  <div style="text-align:center;margin-top:12px"><button class="w-btn w-btn--ghost" id="rs" data-a="resend"${S.cd > 0 ? ' disabled' : ''}>${S.cd > 0 ? 'إعادة الإرسال بعد ' + S.cd + ' ث' : 'إعادة إرسال الرمز'}</button><br><button class="w-btn w-btn--ghost" data-a="changephone">${em ? 'تغيير البريد' : 'تغيير الرقم'}</button></div>
  <div class="note" style="margin-top:20px">${ic('info')}${em ? 'لم يصلك الرمز؟ تحقق من مجلد الرسائل غير المرغوب فيها. ' : ''}لا تشارك هذا الرمز مع أي شخص.</div></div>`;
}
function home() {
  const c = S.d.cards, rw = S.d.rewards || [];
  if (S.e.cards && !c) return errBox();
  if (!c) return skel();
  const xs = c.map((k) => [k, calc(k, rw)]), ready = xs.filter(([, x]) => x.ready).length, near = xs.filter(([, x]) => !x.ready && x.have > 0).sort((a, b) => b[1].pct - a[1].pct)[0];
  const h = new Date().getHours() < 12 ? 'صباح الخير' : 'مساء الخير';
  return `<div class="px"><div class="h"><div style="display:flex;align-items:center;gap:12px"><img alt="" src="./assets/mark.png" style="height:36px"><div><div class="m">${h}</div><b>${esc(S.name || 'عميل وِثاق')}</b></div></div><a class="w-btn w-btn--secondary" aria-label="الإشعارات" href="#/notifications" style="width:48px;padding:0">${ic('bell')}</a></div>
  <div class="hero" style="margin-top:8px"><div class="m">ملخص برامجك</div><div style="display:flex;gap:24px;margin-top:8px"><div><div class="w-num g" style="font-size:36px;font-weight:600;line-height:1.2" data-n="${c.length}">${c.length}</div><div class="m">بطاقات نشطة</div></div><div style="width:1px;background:#303036"></div><div><div class="w-num g" style="font-size:36px;font-weight:600;line-height:1.2" data-n="${ready}">${ready}</div><div class="m">مكافآت جاهزة للاستبدال</div></div></div></div>
  ${near ? sec('تابع تقدمك') + lcard(near[0], near[1]) + `<div style="margin-top:8px;font-weight:600;color:var(--color-accent-text)">${need(near[1])}</div>` : ''}
  ${sec('بطاقاتك', c.length ? '<a href="#/cards">عرض الكل</a>' : '')}${c.length ? xs.slice(0, 2).map(([k, x], i) => `<div style="margin-bottom:12px">${lcard(k, x, i)}</div>`).join('') : empty('لم تنضم إلى أي برنامج ولاء بعد.', 'ستظهر بطاقاتك هنا بعد انضمامك إلى برنامج أي متجر مشارك.', '<a class="w-btn w-btn--primary" href="#/discover">اكتشف المتاجر</a>')}
  ${S.d.stores && S.d.stores.length ? sec('اكتشف المتاجر', '<a href="#/discover">المزيد</a>') + S.d.stores.slice(0, 3).map((s) => row(s, s.name, [s.category, s.area].filter(Boolean).join(' · '), '', '#/store/' + s.id)).join('') : ''}
  ${(S.d.tx || []).length ? sec('آخر العمليات', '<a href="#/activity">نشاطي</a>') + S.d.tx.slice(0, 3).map(txRow).join('') : ''}</div>`;
}
function txRow(t) {
  const m = (t.cards && t.cards.merchants) || { id: t.id, name: '—' }, st = t.cards && t.cards.programs && t.cards.programs.type === 'stamps';
  const label = t.type === 'earn' ? (st ? 'ختم جديد' : 'نقاط مضافة') : t.type === 'redeem' ? 'استبدال مكافأة' : 'تعديل على الرصيد';
  const amt = (t.amount > 0 ? '+' : '') + t.amount;
  return row(m, label, `${m.name} · ${fmtD(t.created_at)} ${fmtT(t.created_at)}`, bd('success', 'check', amt + ' · مؤكدة'));
}
function discover() {
  const st = S.d.stores;
  return `<div class="px"><div class="h"><h1 class="h1">اكتشف</h1></div><input id="q" class="w-input" type="search" placeholder="ابحث باسم المتجر أو التصنيف" value="${esc(S.q)}" aria-label="بحث"><div class="chips">${CATS.map((c) => `<button class="chip${S.cat === c ? ' on' : ''}" data-a="cat:${esc(c)}" aria-pressed="${S.cat === c}">${c}</button>`).join('')}</div><div id="list">${list()}</div></div>`;
}
function list() {
  const st = S.d.stores;
  if (S.e.stores && !st) return errBox();
  if (!st) return skel();
  const f = st.filter((s) => (S.cat === 'الكل' || s.category === S.cat) && (s.name + ' ' + (s.description || '') + ' ' + (s.category || '')).includes(S.q));
  if (!f.length) return `<div class="w-state"><h3>لا توجد متاجر مطابقة</h3><p>جرّب اسمًا أو تصنيفًا آخر.</p></div>`;
  const fav = new Set((S.d.favs || []).map((x) => x.merchant_id));
  return f.map((s) => { const p = (s.programs || [])[0]; return `<div class="w-card" style="margin-bottom:12px"><div style="display:flex;gap:12px">${logo(s, 52)}<div style="flex:1"><b>${esc(s.name)}</b><div class="m">${esc(s.description || s.category || '')}</div><div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap">${p ? bd('info', 'gift', p.type === 'stamps' ? 'برنامج أختام' : 'برنامج نقاط') : ''}${s.is_test ? bd('warning', 'info', 'بيانات تجريبية') : ''}</div></div><button class="w-btn w-btn--ghost" style="width:48px;padding:0${fav.has(s.id) ? '' : ';color:var(--color-text-muted)'}" aria-label="المفضلة" aria-pressed="${fav.has(s.id)}" data-a="fav:${s.id}">${ic('heart', fav.has(s.id) ? 'fill:currentColor' : '')}</button></div><a class="w-btn w-btn--secondary w-btn--block" style="margin-top:12px;min-height:44px;text-decoration:none" href="#/store/${s.id}">عرض المتجر</a></div>`; }).join('');
}
function store(id) {
  const s = (S.d.stores || []).find((x) => x.id === id);
  if (!S.d.stores) return skel();
  if (!s) return `<div class="px">${top('المتجر')}<div class="w-state"><h3>المتجر غير متاح</h3><p>قد يكون متوقفًا أو غير معتمد.</p><a class="w-btn w-btn--secondary" href="#/discover">العودة للاكتشاف</a></div></div>`;
  const p = (s.programs || [])[0], rw = (S.d.rewards || []).filter((r) => p && r.program_id === p.id), joined = p && (S.d.cards || []).find((c) => c.program_id === p.id), r = (p && p.rules) || {};
  return `<div class="px">${top(esc(s.name))}<div style="display:flex;gap:12px;align-items:center">${logo(s, 64)}<div><h1 class="h1" style="font-size:24px">${esc(s.name)}</h1><div class="m">${esc([s.category, s.area, s.city].filter(Boolean).join(' · '))}</div></div></div>${s.description ? `<p style="margin:12px 0">${esc(s.description)}</p>` : ''}${s.is_test ? '<div style="margin:8px 0">' + bd('warning', 'info', 'بيانات تجريبية') + '</div>' : ''}
  ${p ? `${sec('برنامج الولاء')}<div class="w-card"><b>${esc(p.name)}</b><p class="m" style="margin:4px 0 0">${p.type === 'stamps' ? 'بطاقة أختام' : 'برنامج نقاط'}${r.target ? ' · الهدف ' + stT(+r.target) : ''}</p></div>${sec('الشروط')}<div class="w-card"><div class="ro">${ic('check')}<div>${esc(r.earn_text || 'تُعرض شروط الاكتساب عند إضافتها من المتجر.')}</div></div><div class="ro">${ic('gift')}<div>${esc(r.redeem_text || 'تُعرض شروط الاستبدال عند إضافتها من المتجر.')}</div></div></div>${rw.length ? sec('المكافآت') + `<div class="w-card">${rw.map((x) => `<div class="ro"><div><b>${esc(x.title)}</b><div class="m w-num">${p.type === 'stamps' ? stT(x.cost) : ptT(x.cost)}</div></div></div>`).join('')}</div>` : ''}
  <div style="margin:20px 0">${joined ? `<a class="w-btn w-btn--primary w-btn--block" style="text-decoration:none" href="#/card/${joined.id}">عرض بطاقتك</a>` : `<button class="w-btn w-btn--gold w-btn--block" data-a="join:${p.id}"${S.busy ? ' aria-busy="true"' : ''}>انضم إلى برنامج الولاء</button>`}</div>` : '<div class="note" style="margin-top:16px">' + ic('info') + 'لم يُنشر لهذا المتجر برنامج ولاء بعد.</div>'}</div>`;
}
function cards() {
  const c = S.d.cards, rw = S.d.rewards || [];
  if (S.e.cards && !c) return errBox();
  if (!c) return skel();
  const xs = c.map((k) => [k, calc(k, rw)]).filter(([k, x]) => S.cf === 'all' || (S.cf === 'p' && x.type === 'p') || (S.cf === 's' && x.type === 's') || (S.cf === 'r' && x.ready));
  const F = [['all', 'الكل'], ['p', 'النقاط'], ['s', 'الأختام'], ['r', 'مكافآت متاحة']];
  return `<div class="px"><div class="h"><h1 class="h1">بطاقاتي</h1></div><div class="chips">${F.map(([k, l]) => `<button class="chip${S.cf === k ? ' on' : ''}" data-a="cf:${k}" aria-pressed="${S.cf === k}">${l}</button>`).join('')}</div>${xs.length ? `<div style="display:grid;gap:12px">${xs.map(([k, x], i) => lcard(k, x, i)).join('')}</div>` : empty(c.length ? 'لا توجد بطاقات في هذا الفلتر' : 'لم تنضم إلى أي برنامج ولاء بعد.', c.length ? 'جرّب فلترًا آخر.' : 'ستظهر بطاقاتك هنا بعد انضمامك إلى برنامج أي متجر مشارك.', c.length ? '' : '<a class="w-btn w-btn--primary" href="#/discover">اكتشف المتاجر</a>')}</div>`;
}
function card(id) {
  const k = (S.d.cards || []).find((x) => x.id === id);
  if (!S.d.cards) return skel();
  if (!k) return `<div class="px">${top('البطاقة')}<div class="w-state"><h3>البطاقة غير موجودة</h3><a class="w-btn w-btn--secondary" href="#/cards">بطاقاتي</a></div></div>`;
  const x = calc(k, S.d.rewards || []), r = (k.programs && k.programs.rules) || {}, tx = (S.d.tx || []).filter((t) => t.card_id === id);
  const hero = x.type === 's' ? `<div class="w-num" style="text-align:end"><span class="g" style="font-size:48px;font-weight:600;line-height:1">${x.have}</span><span class="m"> / ${x.goal || '—'}</span></div>` : `<div class="w-num" style="text-align:end"><span class="g" style="font-size:48px;font-weight:600;line-height:1">${x.have}</span><span class="m"> نقطة</span></div>`;
  return `<div class="px">${top(x.type === 's' ? 'بطاقة الأختام' : 'بطاقة النقاط')}<div class="hero" style="margin-top:8px"><div style="display:flex;justify-content:space-between;align-items:flex-start"><div><div style="font-size:22px;font-weight:700">${esc(k.merchants.name)}</div><div class="m">${esc(k.programs.name)}</div></div>${hero}</div><div style="margin:20px 0 12px;--color-text-muted:#A9A9B2;color:#fff">${x.type === 's' && x.goal && x.goal <= 12 ? stamps(x.goal, x.have) : pr(x.pct)}</div><div style="font-weight:600">${need(x)}</div></div>
  ${sec('شروط البرنامج')}<div class="w-card"><div class="ro">${ic('check')}<div>${esc(r.earn_text || 'تُعرض شروط الاكتساب عند إضافتها من المتجر.')}</div></div><div class="ro">${ic('gift')}<div>${esc(r.redeem_text || 'تُعرض شروط الاستبدال عند إضافتها من المتجر.')}</div></div></div>
  ${x.R.length ? sec('المكافآت') + `<div class="w-card">${x.R.map((w) => `<div class="ro"><div><b>${esc(w.title)}</b><div class="m w-num">${x.type === 's' ? stT(w.cost) : ptT(w.cost)}</div></div>${x.have >= w.cost ? bd('success', 'check', 'مستحقة') : bd('warning', 'clock', 'ينقصك ' + (x.type === 's' ? stT(w.cost - x.have) : ptT(w.cost - x.have)))}</div>`).join('')}</div>` : ''}
  ${sec('سجل البطاقة')}${tx.length ? tx.map(txRow).join('') : '<p class="m">لا توجد عمليات بعد. ستظهر هنا عند تأكيد أول عملية من المتجر.</p>'}
  <div class="w-card" style="margin:20px 0 8px"><button class="w-btn w-btn--primary w-btn--block" disabled>${x.ready ? 'الاستبدال سيتوفر قريبًا' : 'تحتاج ' + (x.type === 's' ? stT(x.left) : ptT(x.left)) + ' إضافية'}</button><p class="m" style="margin:8px 0 0">ميزتا الاكتساب والاستبدال بالرموز قيد التنفيذ، وتتم دائمًا عبر الخادم.</p></div></div>`;
}
function activity() {
  const t = S.d.tx;
  if (S.e.tx && !t) return errBox();
  if (!t) return skel();
  const g = {}; t.forEach((x) => { (g[fmtD(x.created_at)] = g[fmtD(x.created_at)] || []).push(x); });
  return `<div class="px"><div class="h"><h1 class="h1">نشاطي</h1></div>${t.length ? Object.entries(g).map(([d, a]) => `<div class="m" style="margin-top:16px">${d}</div>${a.map(txRow).join('')}`).join('') : empty('ستظهر هنا عملياتك ومكافآتك', 'عندما تبدأ باستخدام برامج الولاء.', '<a class="w-btn w-btn--primary" href="#/discover">اكتشف المتاجر</a>')}</div>`;
}
function notifications() { return `<div class="px">${top('الإشعارات')}<div class="w-state">${ic('bell', 'width:40px;height:40px')}<h3>الإشعارات غير مفعّلة بعد</h3><p>ستظهر هنا عند تنفيذ خدمة الإشعارات.</p></div></div>`; }
function account() {
  const u = S.user, tier = { bronze: 'برونزي', silver: 'فضي', gold: 'ذهبي' }[S.d.tier && S.d.tier.v] || '—', ph = u.phone ? '+' + u.phone.replace(/^\+/, '') : '', vb = [u.phone ? (u.phone_confirmed_at ? bd('success', 'check', 'الهاتف موثّق') : bd('warning', 'clock', 'الهاتف غير موثّق')) : '', u.email ? (u.email_confirmed_at ? bd('success', 'check', 'البريد موثّق') : bd('warning', 'clock', 'البريد غير موثّق')) : ''].join('');
  return `<div class="px"><div class="h"><h1 class="h1">حسابي</h1></div><div class="w-card" style="display:flex;gap:12px;align-items:center"><span class="w-logo" style="--m:#0B0B0D;color:#F2D98D;width:52px;height:52px;font-size:20px">${esc((S.name || 'ع')[0])}</span><div style="flex:1"><b>${esc(S.name || 'عميل وِثاق')}</b><div class="m w-num" dir="ltr" style="text-align:end">${esc(ph || u.email || '')}</div></div>${bd('info', 'check', tier)}</div>
  <div style="margin:12px 0;display:flex;gap:8px;flex-wrap:wrap">${vb}</div>
  <label class="w-field"><span>الاسم المعروض</span><input id="name" class="w-input" value="${esc(S.name)}" maxlength="60"></label><button class="w-btn w-btn--secondary" data-a="savename">حفظ الاسم</button>
  <div class="m" style="margin:20px 0 8px">المظهر</div><div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">${[['', 'تلقائي'], ['light', 'فاتح'], ['dark', 'داكن']].map(([v, l]) => `<button class="chip${S.theme === v ? ' on' : ''}" style="justify-content:center;min-height:48px;border-radius:12px" data-a="theme:${v}" aria-pressed="${S.theme === v}">${l}</button>`).join('')}</div>
  <button class="w-btn w-btn--secondary w-btn--block" style="margin-top:24px" data-a="logout">تسجيل الخروج</button>
  <div style="margin-top:48px;text-align:center"><button class="w-btn w-btn--ghost" style="color:var(--color-danger)" data-a="delreq">طلب حذف الحساب</button><p class="m" style="font-size:12px">نسخة الاختبار 0.2 · بيئة التطوير</p></div></div>`;
}
// ---------- motion: Meniscus dock (route-driven; the bead follows the current tab, tap or drag to navigate) ----------
const DR = [['home', 'الرئيسية', 'home'], ['discover', 'اكتشف', 'compass'], ['cards', 'بطاقاتي', 'cards'], ['activity', 'نشاطي', 'act'], ['account', 'حسابي', 'user']];
const RM = typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;
// A session alone is not proof of verification: require a confirmed phone or email.
const confirmed = (u) => !!(u && (u.phone_confirmed_at || u.email_confirmed_at || u.confirmed_at));
function countUp() {
  const m = $('#main'); if (!m || !m.querySelectorAll || RM || typeof requestAnimationFrame !== 'function') return;
  m.querySelectorAll('[data-n]').forEach((el) => { const to = +el.dataset.n, t0 = performance.now(); if (!to) return; (function f(n) { const p = Math.min((n - t0) / 900, 1); el.textContent = p < 1 ? Math.round(to * (1 - Math.pow(2, -10 * p))) : to; if (p < 1) requestAnimationFrame(f); })(t0); });
}
let dk = null;
function dockSync(i) { dockInit(); if (dk) dk.sync(i); }
function dockInit() {
  if (dk || typeof ResizeObserver === 'undefined' || !document.body) return;
  const NS = 'http://www.w3.org/2000/svg', N = DR.length, BT = 30, SH = 92, BR = 26, CR = 20, SB = 30, CP = 13, TRV = 27, ENT = 38, cl = (x, a, b) => Math.max(a, Math.min(b, x));
  const el = document.createElement('nav'); el.className = 'w-dock'; el.setAttribute('aria-label', 'التنقل الرئيسي'); el.style.display = 'none';
  el.innerHTML = `<svg class="dsv" aria-hidden="true"></svg><div class="bead" aria-hidden="true"><i class="bg"></i><i class="bc"></i><div class="bcl">${DR.map((d) => ic(d[2])).join('')}</div></div><div class="tabs">${DR.map(([r, l, i]) => `<a href="#/${r}" class="tab" draggable="false"><span class="ti">${ic(i)}</span><span class="tl">${l}</span></a>`).join('')}</div>`;
  document.body.appendChild(el);
  const sv = el.querySelector('.dsv'), bead = el.querySelector('.bead'), tabs = [...el.querySelectorAll('.tab')], tI = [...el.querySelectorAll('.ti')], tL = [...el.querySelectorAll('.tl')], bI = [...el.querySelectorAll('.bcl .w-ico')];
  const mk = (c) => { const p = document.createElementNS(NS, 'path'); p.setAttribute('class', c); sv.appendChild(p); return p; }, pF = mk('pf'), pB = mk('pb'), rim = mk('rim');
  let W = 0, tw = 0, C = [], ax = 0, tx = 0, vel = 0, raf = 0, lt = 0, act = 0, shown = false, drag = false, moved = false, sx = 0, scx = 0, si = 0, lx = 0, lmt = 0, dv = 0, dr = 0;
  const np = (cx, v) => { const m = Math.min(Math.abs(v) / 1300, 1), g = v > 0 ? 1 : -1, sL = SB * (1 + .06 * m + .38 * g * m), sR = SB * (1 + .06 * m - .38 * g * m), lx_ = Math.max(CR, cx - sL), rx = Math.min(W - CR, cx + sR), aL = cx - lx_, aR = rx - cx; return { lx: lx_, rx, ny: BT + BR * .86, a: lx_ + Math.min(CP, aL * .45), b: cx - Math.min(13, aL * .5), c: cx + Math.min(13, aR * .5), d: rx - Math.min(CP, aR * .45) }; };
  const draw = (cx, v) => {
    const p = np(cx, v), T = BT, B = SH, w = W, rm = `M ${p.lx},${T} C ${p.a},${T} ${p.b},${p.ny} ${cx},${p.ny} C ${p.c},${p.ny} ${p.d},${T} ${p.rx},${T}`;
    const pd = `M ${CR},${T} L ${p.lx},${T} ${rm.slice(rm.indexOf('C'))} L ${w - CR},${T} Q ${w},${T} ${w},${T + CR} L ${w},${B - CR} Q ${w},${B} ${w - CR},${B} L ${CR},${B} Q 0,${B} 0,${B - CR} L 0,${T + CR} Q 0,${T} ${CR},${T} Z`;
    pF.setAttribute('d', pd); pB.setAttribute('d', pd); rim.setAttribute('d', rm);
    const s = Math.min(Math.abs(v) / 5000, .16); bead.style.transform = `translate3d(${cx - 26}px,0,0) scale(${1 + s},${1 - s * .45})`;
    for (let i = 0; i < N; i++) { let q = cl(1 - Math.abs(cx - C[i]) / (tw * .6), 0, 1); q = q * q * (3 - 2 * q); tI[i].style.transform = `translate3d(0,${-q * TRV}px,0)`; tI[i].style.opacity = 1 - q; bI[i].style.transform = `translate3d(0,${(1 - q) * ENT}px,0)`; bI[i].style.opacity = q; tL[i].style.opacity = q; tL[i].style.transform = `translate3d(0,${(1 - q) * 5}px,0)`; }
  };
  const stop = () => { cancelAnimationFrame(raf); raf = 0; };
  const step = (n) => { const dt = Math.min((n - lt) / 1000, 1 / 30); lt = n; for (let k = Math.max(1, Math.round(dt * 120)); k--;) { vel += (-420 * (ax - tx) - 34 * vel) / 120; ax += vel / 120; } if (Math.abs(ax - tx) < .05 && Math.abs(vel) < 2) { ax = tx; vel = 0; draw(ax, 0); raf = 0; return; } draw(ax, vel); raf = requestAnimationFrame(step); };
  const spring = (x, v) => { tx = x; if (RM) { stop(); ax = x; vel = 0; draw(ax, 0); return; } if (v !== undefined) vel = v; if (!raf) { lt = performance.now(); raf = requestAnimationFrame(step); } };
  const layout = () => { W = el.offsetWidth; const d = el.getBoundingClientRect(); C = tabs.map((t) => { const r = t.getBoundingClientRect(); return r.left - d.left + r.width / 2; }); tw = Math.abs(C[0] - C[1]) || W / N; sv.setAttribute('viewBox', `0 0 ${W} ${SH}`); if (shown) { stop(); ax = tx = C[act]; vel = 0; draw(ax, 0); } };
  const near = (cx) => C.reduce((b, c, i) => (Math.abs(cx - c) < Math.abs(cx - C[b]) ? i : b), 0);
  const go = (i) => { spring(C[i]); const h = '#/' + DR[i][0]; if (location.hash !== h) location.hash = h; };
  const dLoop = () => { if (!drag || !moved) { dr = 0; return; } if (performance.now() - lmt > 40) dv *= .85; draw(ax, dv); dr = requestAnimationFrame(dLoop); };
  el.addEventListener('pointerdown', (e) => { stop(); drag = true; moved = false; sx = lx = e.clientX; scx = ax; si = act; lmt = performance.now(); dv = vel = 0; el.setPointerCapture(e.pointerId); });
  el.addEventListener('pointermove', (e) => {
    if (!drag) return; const dx = e.clientX - sx;
    if (!moved && Math.abs(dx) > 6) { moved = true; if (!dr) dr = requestAnimationFrame(dLoop); } if (!moved) return;
    const mn = Math.min(...C), mx = Math.max(...C); let cx = scx + dx; if (cx < mn) cx = mn - Math.min((mn - cx) * .25, 14); else if (cx > mx) cx = mx + Math.min((cx - mx) * .25, 14);
    ax = tx = cx; vel = 0; const n = performance.now(), t = n - lmt; if (t > 0) dv = dv * .6 + ((e.clientX - lx) / t * 1000) * .4; lx = e.clientX; lmt = n; draw(cx, dv);
  });
  const end = (e, cancel) => {
    if (!drag) return; drag = false; try { el.releasePointerCapture(e.pointerId); } catch (_) {}
    if (cancel) return spring(C[act]);
    if (!moved) return go(near(e.clientX - el.getBoundingClientRect().left));
    const ve = performance.now() - lmt > 80 ? 0 : dv; let t = near(ax);
    if (Math.abs(ve) > 400 && Math.abs(e.clientX - sx) > W * .08 && t === si) { const o = [...C.keys()].sort((a, b) => C[a] - C[b]); t = o[cl(o.indexOf(si) + (ve > 0 ? 1 : -1), 0, N - 1)]; }
    go(t); vel = cl(ve, -1800, 1800);
  };
  el.addEventListener('pointerup', (e) => end(e, false)); el.addEventListener('pointercancel', (e) => end(e, true));
  el.addEventListener('click', (e) => { if (e.detail) e.preventDefault(); });
  el.addEventListener('dragstart', (e) => e.preventDefault()); // pointer taps are handled above; keyboard activation keeps the native link
  new ResizeObserver(layout).observe(el);
  dk = { sync(i) { if (i < 0) { el.style.display = 'none'; shown = false; return; } act = i; tabs.forEach((t, k) => (k === i ? t.setAttribute('aria-current', 'page') : t.removeAttribute('aria-current'))); if (!shown) { el.style.display = ''; shown = true; layout(); stop(); ax = tx = C[i]; vel = 0; draw(ax, 0); } else if (!drag) spring(C[i]); } };
}

// ---------- router ----------
const AUTH = ['login', 'otp'];
function parse() { const [r = '', id = ''] = location.hash.replace(/^#\//, '').split('/'); return [r, id]; }
function screen() {
  if (!sb) return '<div class="px"><div class="note" style="margin-top:48px">' + ic('x') + 'إعدادات الاتصال (config.js) غير مكتملة.</div></div>';
  const [r, id] = parse();
  return { login, otp, home, discover, store: () => store(id), cards, card: () => card(id), activity, notifications, account }[r]();
}
function render() {
  if (!sb) { $('#app').innerHTML = screen(); return; }
  let [r, id] = parse();
  if (!S.user && !AUTH.includes(r)) { location.hash = '#/login'; return; }
  if (S.user && (AUTH.includes(r) || !r)) { location.hash = '#/home'; return; }
  if (!S.user && r === 'otp' && !(S.email || S.phone)) { location.hash = '#/login'; return; } // reload on the code screen with nothing pending
  if (!screen.length && false) return;
  const known = ['login', 'otp', 'home', 'discover', 'store', 'cards', 'card', 'activity', 'notifications', 'account'];
  if (!known.includes(r)) { location.hash = S.user ? '#/home' : '#/login'; return; }
  const banner = !S.online ? `<div class="off" role="status">${ic('off')}أنت غير متصل. نعرض آخر بيانات محفوظة.</div>` : S.stale && S.user ? `<div class="off" role="status">${ic('clock')}تعذّر تحديث بعض البيانات. نعرض آخر نسخة محفوظة.</div>` : '';
  const main = ['home', 'discover', 'cards', 'activity', 'account'].includes(r) ? r : r === 'store' ? 'discover' : r === 'card' ? 'cards' : '';
  const key = r + '/' + id + '/' + (S.d.cards ? 1 : 0) + (S.d.stores ? 1 : 0), enter = key !== S.rk; S.rk = key; // entrance motion only when the screen or its data actually changes
  $('#app').innerHTML = banner + `<main id="main"${enter ? ' class="enter"' : ''}>${screen()}</main>`;
  document.documentElement.setAttribute('data-theme', S.theme);
  dockSync(S.user && !AUTH.includes(r) && r !== 'notifications' ? DR.findIndex((d) => d[0] === main) : -1);
  if (enter) countUp();
}
// ---------- actions ----------
const AERR = (e) => {
  const m = ((e && e.message) || '').toLowerCase(), c = ((e && e.code) || '').toLowerCase(), st = e && e.status;
  if (!navigator.onLine || m.includes('fetch') || m.includes('network')) return 'تعذّر الاتصال. تحقق من الإنترنت ثم حاول مجددًا.';
  if (st === 429 || c.includes('rate_limit') || m.includes('rate limit') || m.includes('seconds')) return 'تم إرسال طلبات كثيرة. انتظر قليلًا ثم حاول مجددًا.';
  if (c === 'otp_expired') return 'انتهت صلاحية الرمز. اطلب رمزًا جديدًا.';
  if (m.includes('token') || m.includes('otp') || m.includes('expired')) return 'الرمز غير صحيح أو انتهت صلاحيته.';
  if ((m.includes('email') && m.includes('invalid')) || c === 'email_address_invalid' || c === 'validation_failed') return 'البريد الإلكتروني غير صالح.';
  if (m.includes('provider') || m.includes('not enabled') || m.includes('unsupported') || c.includes('disabled')) return 'تسجيل الدخول بهذه الطريقة غير مفعّل بعد في هذه البيئة.';
  if (st >= 500 || m.includes('sending') || m.includes('smtp') || c === 'unexpected_failure') return 'تعذّر إرسال الرسالة الآن. حاول مرة أخرى بعد قليل.';
  return 'تعذّر إتمام العملية. حاول مرة أخرى.';
};
const toast = (t) => { const e = document.createElement('div'); e.className = 'w-toast'; e.setAttribute('role', 'status'); e.style.cssText = 'position:fixed;inset-inline:16px;bottom:88px;max-width:448px;margin:0 auto;z-index:9'; e.textContent = t; document.body.appendChild(e); setTimeout(() => e.remove(), 3000); };
function normPhone(v) { v = v.replace(/[\s\-()]/g, '').replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)); if (v.startsWith('+')) return /^\+\d{8,15}$/.test(v) ? v : null; v = v.replace(/^00/, ''); if (v.startsWith('967')) v = v.slice(3); v = v.replace(/^0/, ''); return /^7\d{8}$/.test(v) ? '+967' + v : null; }
let tick;
const left = () => Math.max(0, Math.ceil((S.until - Date.now()) / 1000));
function startTick() { clearInterval(tick); S.cd = left(); tick = setInterval(() => { S.cd = left(); const b = $('#rs'); if (b) { b.textContent = S.cd > 0 ? 'إعادة الإرسال بعد ' + S.cd + ' ث' : 'إعادة إرسال الرمز'; b.disabled = S.cd > 0; } if (!S.cd) clearInterval(tick); }, 1000); }
function countdown() { S.until = Date.now() + 60000; startTick(); }
// The pending code screen survives a page refresh (tab-scoped storage; never stores the code itself).
const PEND = 'w-pend';
const savePend = () => ss.set(PEND, { chan: S.chan, email: S.email, phone: S.phone, until: S.until, tries: S.tries });
function restorePend() { const p = ss.get(PEND); if (!p || !(p.email || p.phone)) return; Object.assign(S, { chan: p.chan === 'email' ? 'email' : 'phone', email: p.email || '', phone: p.phone || '', until: +p.until || 0, tries: +p.tries || 0, step: 'otp' }); S.last = S.chan === 'email' ? S.email : S.phone; startTick(); }
async function busy(fn) { if (S.busy) return; S.busy = true; render(); try { await fn(); } finally { S.busy = false; render(); } }
async function sendOtp(chan, resend) {
  if (chan) S.chan = chan; S.err = ''; S.info = ''; let args;
  if (S.chan === 'email') { const em = S.email.trim().toLowerCase(); if (!/^\S+@\S+\.\S+$/.test(em)) { S.err = 'أدخل بريدًا إلكترونيًا صحيحًا.'; render(); return; } S.email = em; args = { email: em, options: { shouldCreateUser: true } }; }
  else { const p = normPhone(S.phone); if (!p) { S.err = 'أدخل رقم هاتف صحيحًا مكوّنًا من 9 أرقام يبدأ بـ 7.'; render(); return; } args = { phone: p }; }
  const tgt = S.chan === 'email' ? S.email : args.phone;
  if (!resend && S.last === tgt && left() > 0) { S.tok = ''; S.step = 'otp'; location.hash = '#/otp'; return; } // code already sent to this destination: do not spam
  await busy(async () => { const { error } = await sb.auth.signInWithOtp(args); if (error) { S.err = AERR(error); return; } if (args.phone) S.phone = args.phone; S.last = tgt; S.tok = ''; S.tries = 0; S.step = 'otp'; countdown(); savePend(); location.hash = '#/otp'; });
}
async function verify() {
  S.err = ''; const t = digits(S.tok); if (!/^\d{6}$/.test(t)) { S.err = 'أدخل الرمز المكوّن من 6 أرقام.'; render(); return; }
  if (S.tries >= 5) { S.err = 'تجاوزت عدد المحاولات. اطلب رمزًا جديدًا ثم أعد المحاولة.'; render(); return; }
  const args = S.chan === 'email' ? { email: S.email, token: t, type: 'email' } : { phone: S.phone, token: t, type: 'sms' };
  await busy(async () => { const { error } = await sb.auth.verifyOtp(args); if (error) { S.tries++; savePend(); S.err = AERR(error); S.tok = ''; return; } ss.del(PEND); S.tries = 0; });
}
async function act(a, v, el) {
  if (a === 'back') return history.length > 1 ? history.back() : (location.hash = '#/home');
  if (a === 'retry') { S.d = {}; render(); return loadAll(); }
  if (a === 'cat') { S.cat = v; return render(); }
  if (a === 'cf') { S.cf = v; return render(); }
  if (a === 'theme') { S.theme = v; ls.set('w-theme', v); return render(); }
  if (a === 'sendotp') return sendOtp('phone');
  if (a === 'resend') { if (S.cd > 0) return; S.err = ''; return sendOtp(undefined, true); }
  if (a === 'verify') return verify();
  if (a === 'changephone') { S.step = 'phone'; S.err = ''; S.tok = ''; ss.del(PEND); location.hash = '#/login'; return; }
  if (a === 'emailopen') { S.emailOpen = true; return render(); }
  if (a === 'email') return sendOtp('email');
  if (a === 'google') { const { error } = await sb.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: location.origin + location.pathname } }); if (error) { S.err = AERR(error); render(); } return; }
  if (a === 'fav') { const on = (S.d.favs || []).some((f) => f.merchant_id === v); const { error } = on ? await sb.from('favorites').delete().eq('merchant_id', v).eq('user_id', S.user.id) : await sb.from('favorites').insert({ merchant_id: v, user_id: S.user.id }); if (error) return toast('تعذّر تحديث المفضلة. تحقق من الاتصال.'); S.d.favs = on ? S.d.favs.filter((f) => f.merchant_id !== v) : [...(S.d.favs || []), { merchant_id: v }]; return render(); }
  if (a === 'join') return busy(async () => { const { data, error } = await sb.rpc('join_program', { p_program_id: v }); if (error) { toast(error.code === 'P0002' ? 'هذا البرنامج غير متاح حاليًا.' : 'تعذّر الانضمام. حاول مرة أخرى.'); return; } await load('cards', () => q(sb.from('cards').select('id,stamps,points,created_at,program_id,merchant_id,programs(id,type,name,rules),merchants(id,name,category,is_test)').order('created_at', { ascending: false }))); toast('انضممت إلى البرنامج.'); location.hash = '#/card/' + data; });
  if (a === 'savename') return busy(async () => { const { error } = await sb.from('profiles').update({ display_name: S.name.trim() || null }).eq('id', S.user.id); toast(error ? 'تعذّر حفظ الاسم.' : 'تم حفظ الاسم.'); });
  if (a === 'delreq') { if (!confirm('سيُسجَّل طلب حذف حسابك وتتم مراجعته وفق سياسة الخصوصية. هل تريد المتابعة؟')) return; return busy(async () => { const { error } = await sb.from('profiles').update({ deletion_requested_at: new Date().toISOString() }).eq('id', S.user.id); toast(error ? 'تعذّر تسجيل الطلب.' : 'تم تسجيل طلب حذف الحساب.'); }); }
  if (a === 'logout') { await sb.auth.signOut(); }
}
document.addEventListener('click', (e) => { const t = e.target.closest('[data-a]'); if (!t || t.disabled) return; const i = t.dataset.a.indexOf(':'); const a = i < 0 ? t.dataset.a : t.dataset.a.slice(0, i), v = i < 0 ? '' : t.dataset.a.slice(i + 1); act(a, v, t); });
document.addEventListener('input', (e) => { const id = e.target.id; if (id === 'phone') S.phone = e.target.value; else if (id === 'tok') { S.tok = digits(e.target.value).slice(0, 6); if (e.target.value !== S.tok) e.target.value = S.tok; if (S.tok.length === 6) verify(); } else if (id === 'email') S.email = e.target.value; else if (id === 'name') S.name = e.target.value; else if (id === 'q') { S.q = e.target.value.trim(); const l = $('#list'); if (l) l.innerHTML = list(); } });
document.addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target.id === 'phone') sendOtp('phone'); if (e.key === 'Enter' && e.target.id === 'email') sendOtp('email'); if (e.key === 'Enter' && e.target.id === 'tok') verify(); });
window.addEventListener('hashchange', () => { S.err = ''; render(); window.scrollTo(0, 0); });
window.addEventListener('online', () => { S.online = true; render(); if (S.user) loadAll(); });
window.addEventListener('offline', () => { S.online = false; render(); });
// ---------- start ----------
async function init() {
  document.documentElement.setAttribute('data-theme', S.theme);
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(() => {});
  if (sb) {
    try { const r = await fetch(CFG.url + '/auth/v1/settings', { headers: { apikey: CFG.key } }); const j = await r.json(); const x = j.external || {}; S.authCfg = { phone: !!x.phone, email: !!x.email, google: !!x.google }; } catch { S.authCfg = { phone: true, email: false, google: false }; }
    const { data } = await sb.auth.getSession(); S.user = data.session && confirmed(data.session.user) ? data.session.user : null; if (data.session && !S.user) sb.auth.signOut(); if (!S.user) restorePend();
    sb.auth.onAuthStateChange((ev, s) => { const was = S.user; if (s && !confirmed(s.user)) { S.user = null; setTimeout(() => sb.auth.signOut(), 0); return; } S.user = s ? s.user : null; if (ev === 'SIGNED_OUT') { Object.keys(localStorage).filter((k) => k.startsWith('wc:')).forEach((k) => ls.del(k)); S.d = {}; S.e = {}; S.phone = S.tok = S.email = S.last = ''; S.until = S.cd = S.tries = 0; ss.del(PEND); location.hash = '#/login'; render(); } else if (S.user && !was) { S.d = {}; S.last = ''; S.until = S.cd = S.tries = 0; ss.del(PEND); location.hash = '#/home'; render(); loadAll(); } });
  }
  render(); if (S.user) loadAll();
  const sp = $('#splash'); if (sp) { sp.classList.add('out'); setTimeout(() => sp.remove(), 400); }
}
init();
