# WATHAQ v0.6 — Authentication refresh fix report

## Scope
Focused repair for the reported case: email OTP is requested successfully, but refreshing the OTP page resets the UI to the phone/SMS channel.

## Root cause confirmed in source
- `S.chan` defaulted to `phone` on every JavaScript module load.
- `S.email` was also reset to an empty string.
- The `#/otp` route was restored by the URL, but the channel and destination were not restored with it.
- The error mapper treated any message containing `fetch` as an internet outage, even when the device remained online and the remote service was the failing component.
- Auth settings failure defaulted email to disabled, potentially making the login screen inconsistent on a later load.
- The service worker used cache-first behavior for same-origin app resources, allowing stale app code to remain active.

## Changes
- Persist only pending auth metadata (channel, email/phone destination, creation time, resend cooldown) for up to 10 minutes.
- Never persist the OTP/token.
- Restore `#/otp`, the selected channel, and the masked destination after reload.
- Restore the resend cooldown without restarting the full 60 seconds.
- Clear pending metadata on successful sign-in, sign-out, or changing the destination.
- Cache the last successful auth-provider settings; if settings cannot be fetched, retain the email path rather than falsely disabling it.
- Improve Arabic error classification so an online device with an unreachable Supabase endpoint is not told that its internet is disconnected.
- Bump the service-worker cache version and use network-first for navigations and JS/CSS; Supabase Auth and API requests are not cached.
- Rebuilt `public/index.html` from `app/src/app.mjs` using the repository build script.

## Files changed
- `app/src/app.mjs`
- `app/sw.js`
- `public/index.html` (generated)
- `public/sw.js` (copied from app service worker)
- `app/test/auth-refresh.smoke.mjs`
- `docs/AUTH_FIX_REPORT.md`

## Verification
- Existing customer-app smoke suite: 51/51 passed.
- Auth refresh-state smoke checks: 4/4 passed.
- These are local automated checks. A live Supabase email delivery test and a real-device refresh test are still required.

## Deployment note
Deploy the rebuilt `public/` directory (not only `app/src/app.mjs`). After deployment, test in a private/incognito browser or clear the old site cache once to avoid testing a previously installed service worker.
